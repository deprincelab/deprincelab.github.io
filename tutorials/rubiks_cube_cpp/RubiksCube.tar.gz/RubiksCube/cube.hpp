#ifndef CUBE_HPP
#define CUBE_HPP

#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include<time.h>
#include<GL/gl.h>
#include<GL/glut.h>
#include<GL/glu.h>

#define RED 0
#define GREEN 1
#define BLUE 2
#define YELLOW 3
#define WHITE 4
#define CYAN 5
#define ORANGE 5

#define U 0
#define F 1
#define L 2
#define B 3
#define R 4
#define D 5

using namespace std;

/// 
struct adjacent{
  int **face,**color;
};

class RubiksCube
{
  public:

    /// constructor
    RubiksCube();

    /// denstructor
    ~RubiksCube();

    /// bring face to front
    void BringToFront(int face);

    /// bring face to top
    void BringToTop(int face);

    /// rotate right face clockwise
    void MoveR();

    /// rotate right face twice
    void MoveR2();

    /// rotate right face counterclockwise 
    void MoveRprime();

    /// rotate left face clockwise 
    void MoveL();

    /// rotate left face twice
    void MoveL2();

    /// rotate left face counterclockwise
    void MoveLprime();

    /// rotate upper face clockwise 
    void MoveU();

    /// rotate upper face twice
    void MoveU2();

    /// rotate upper face counterclockwise
    void MoveUprime();

    /// rotate lower face clockwise
    void MoveD();

    /// rotate lower face twice
    void MoveD2();

    /// rotate lower face counterclockwise 
    void MoveDprime();

    /// rotate front face clockwise
    void MoveF();

    /// rotate front face twice
    void MoveF2();

    /// rotate front face counterclockwise
    void MoveFprime();

    /// rotate back face clockwise
    void MoveB();

    /// rotate back face twice
    void MoveB2();

    /// rotate back face counterclockwise
    void MoveBprime();

    /// print cube in 2D format
    void PrintCube();

    /// print cube in 3D
    void PrintCube3D();

    /// return total number of moves
    int total_moves(){ return moves; }

  protected:

    /// cube data
    int **cube_data;

    /// temporary container for cube data
    int **temp_cube_data;

    /// copy temp_cube_data into cube_data
    void CopyCube();

    /// print one square of cube for 2D format
    void PrintElement(int element);

    /// has the cross been formed?
    int FormedCross;

    /// is the top layer solved?
    int SolvedTop;

    /// is the middle layer solved?
    int SolvedMiddle;

    /// flag so printing is avoided while randomizing initial state
    int setup;

    /// running count of moves
    int moves;

    /// have various parts of the top been solved?
    int *TopSolved;

    /// have various parts of the middle been solved?
    int **MiddleSolved;

    /// what edge colors are adjacent 
    adjacent side;

    /// what corner colors are adjacent 
    adjacent corner;

    /// what corner colors are adjacent 
    adjacent cornerprime;

    /// randomize cube
    void JumbleCube();

    /// checks which colors are adjacent on corners and edges
    void IsTouching();

    /// checks progress toward solution
    void IsSolved();

    // building blocks for moving pieces
    void RotateFace(int face);
    void RotateEquatorX();
    void RotateEquatorY();
    void RotateEquatorZ();
    void RotateRight();
    void RotateLeft();
    void RotateUp();
    void RotateDown();
    void RotateFront();
    void RotateBack();

};

void Square(double x1,double y1,double z1,double x2,double y2,double z2);
void SquarePrime(double x1,double y1,double z1,double x2,double y2,double z2);
void SetColor(int color);

#endif
