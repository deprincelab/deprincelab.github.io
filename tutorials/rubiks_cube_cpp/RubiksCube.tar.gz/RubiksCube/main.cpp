#include<stdio.h> 
#include<memory>

// OpenGL headers
#include<GL/gl.h>
#include<GL/glu.h>
#include<GL/glut.h>

#include"cube.hpp"
#include"cube_solver.hpp"

// avoid pressing enter after getchar()
#ifdef LINUX

#include<termios.h>
#include<unistd.h>

#endif

std::shared_ptr<RubiksCube> global_cube;

void display(void){

  // clear
  glClear (GL_COLOR_BUFFER_BIT);
  glTranslatef(-.05,0.05,0);


#ifdef INTERACTIVE
  global_cube = (std::shared_ptr<RubiksCube>)(new RubiksCube());
  do {
      char ch = getchar();
      if ( ch == 'r' ) {
          global_cube->MoveR();
      }else if ( ch == 'R' ) {
          global_cube->MoveRprime();
      }else if ( ch == 'l' ) {
          global_cube->MoveL();
      }else if ( ch == 'L' ) {
          global_cube->MoveLprime();
      }else if ( ch == 'u' ) {
          global_cube->MoveU();
      }else if ( ch == 'U' ) {
          global_cube->MoveUprime();
      }else if ( ch == 'f' ) {
          global_cube->MoveF();
      }else if ( ch == 'F' ) {
          global_cube->MoveFprime();
      }else if ( ch == 'b' ) {
          global_cube->MoveB();
      }else if ( ch == 'B' ) {
          global_cube->MoveBprime();
      }else if ( ch == 'd' ) {
          global_cube->MoveD();
      }else if ( ch == 'D' ) {
          global_cube->MoveDprime();
      }else if (ch == '\033') { // if the first value is esc
          getchar(); // skip the [
          switch(getchar()) { // the real value
              case 'A':
                  // code for arrow up
                  global_cube->BringToTop(F);
                  break;
              case 'B':
                  // code for arrow down
                  global_cube->BringToTop(B);
                  break;
              case 'C':
                  // code for arrow right
                  global_cube->BringToFront(L);
                  break;
              case 'D':
                  // code for arrow left
                  global_cube->BringToFront(R);
                  break;
          }
      }
  }while(1);
#else
  // your solution goes here!
  //std::shared_ptr<RubiksCube> cube (new RubiksCube());

  // eugene's solution
  std::shared_ptr<RubiksCubeSolver> cube (new RubiksCubeSolver());

  cube->LocateOrigin();
  cube->FormCross();
  cube->SolveTopLayer();
  cube->SolveMiddleLayer();
  cube->FormBottomCross();
  cube->PermuteBottomCorners();
  printf("  permute bottom corners   moves: %3i\n",cube->total_moves());
#ifdef PAUSE
  char ch = getchar();
#endif
  cube->OrientBottomCorners();
  cube->PermuteBottomEdges();

  cube->PrintCube3D();
  printf("\n moves to solution: %3i\n",cube->total_moves());
#endif

}

void keyboard(unsigned char key, int x, int y){
    if ( key == 'r' ) {
        global_cube->MoveR();
    }else if ( key == 'R' ) {
        global_cube->MoveRprime();
    }else if ( key == 'l' ) {
        global_cube->MoveL();
    }else if ( key == 'L' ) {
        global_cube->MoveLprime();
    }else if ( key == 'u' ) {
        global_cube->MoveU();
    }else if ( key == 'U' ) {
        global_cube->MoveUprime();
    }else if ( key == 'f' ) {
        global_cube->MoveF();
    }else if ( key == 'F' ) {
        global_cube->MoveFprime();
    }else if ( key == 'b' ) {
        global_cube->MoveB();
    }else if ( key == 'B' ) {
        global_cube->MoveBprime();
    }else if ( key == 'd' ) {
        global_cube->MoveD();
    }else if ( key == 'D' ) {
        global_cube->MoveDprime();
    }
}
void keyboard_arrows(int key, int x, int y){
    if (key == GLUT_KEY_UP) {
        global_cube->BringToTop(F);
    }else if (key == GLUT_KEY_DOWN) {
        global_cube->BringToTop(B);
    }else if (key == GLUT_KEY_LEFT) {
        global_cube->BringToFront(R);
    }else if (key == GLUT_KEY_RIGHT) {
        global_cube->BringToFront(L);
    }
}

void init (void) 
{
  //  select background color (white)
  glClearColor (1.0, 1.0, 1.0, 0.0);
  
  //glEnable(GL_DEPTH_TEST);

  /*  initialize viewing values  */
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  glOrtho(0.0, 1.0, 0.0, 1.0, -1.0, 1.0);
}

int main(int argc, char** argv){

#ifdef LINUX
    int c;   
    static struct termios oldt, newt;

    /*tcgetattr gets the parameters of the current terminal
    STDIN_FILENO will tell tcgetattr that it should write the settings
    of stdin to oldt*/
    tcgetattr( STDIN_FILENO, &oldt);
    /*now the settings will be copied*/
    newt = oldt;

    /*ICANON normally takes care that one line at a time will be processed
    that means it will return if it sees a "\n" or an EOF or an EOL*/
    newt.c_lflag &= ~(ICANON);          

    /*Those new settings will be set to STDIN
    TCSANOW tells tcsetattr to change attributes immediately. */
    tcsetattr( STDIN_FILENO, TCSANOW, &newt);
#endif

    srand(time(0));
    using namespace std;
    
    // initialize OpenGL stuff
    glutInit(&argc, argv);
    glutInitDisplayMode (GLUT_DOUBLE | GLUT_RGB);
    glutInitWindowSize (500, 500); 
    glutInitWindowPosition (50, 50);
    glutCreateWindow ("Rubik's cube");
    glEnable(GL_CULL_FACE);
  
    init();
  
    // define the keyboard function. for interactive mode
    glutKeyboardFunc(keyboard); 
    //glutSpecialFunc(keyboard_arrows); 

    // define the display function. this is where the solver logic lives
    glutDisplayFunc(display); 
    glutMainLoop();
  
    return 0; 
}

