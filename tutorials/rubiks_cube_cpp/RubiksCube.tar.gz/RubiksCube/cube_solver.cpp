/*
 *
 * This file contains functions for algorithms that execute a beginner's solution
 *
**/

#include "cube_solver.hpp"

RubiksCubeSolver::RubiksCubeSolver()
    : RubiksCube() {
}

RubiksCubeSolver::~RubiksCubeSolver(){
}

void RubiksCubeSolver::LocateOrigin(){
    moves = 0;
    setup = 0;
    for (int i = 0; i < 6; i++) {
      if (cube_data[i][4] == WHITE){
         BringToTop(i);
         break;
      }
    }
#ifdef PAUSE
    char ch = getchar();
#endif
}

void RubiksCubeSolver::FormCross(){

    for (int i = 0; i < 4; i++) {

        // Locate a white side piece
        int rotate = -1;
        int face;
        for (face = 1; face < 6; face++){
            if (cube_data[face][1]==WHITE){
                rotate = side.face[face][1];
                break;
            }
            if (cube_data[face][3]==WHITE){
                rotate = side.face[face][3];
                break;
            }
            if (cube_data[face][5]==WHITE){
                rotate = side.face[face][5];
                break;
            }
            if (cube_data[face][7]==WHITE){
                rotate = side.face[face][7];
                break;
            }
        }
        if (rotate==-1){
            // a side piece is on the top in the wrong place:w
            if (cube_data[U][1]==WHITE && side.color[U][1] != cube_data[B][4]) MoveB2();
            if (cube_data[U][3]==WHITE && side.color[U][3] != cube_data[L][4]) MoveL2();
            if (cube_data[U][5]==WHITE && side.color[U][5] != cube_data[R][4]) MoveR2();
            if (cube_data[U][7]==WHITE && side.color[U][7] != cube_data[F][4]) MoveF2();
            face = D;
        }
        // Move that side piece to top
        GetToBottom(WHITE,face);
        GetToTop();

    }

    FormedCross = 1;
    printf("  formed cross             moves: %3i\n",moves);

#ifdef PAUSE
    char ch = getchar();
#endif
}

void RubiksCubeSolver::GetToBottom(int color,int face){

    int sideface;

    if (face==D) return;

    BringToFront(face);

    if      (cube_data[F][1]==color) sideface = U;
    else if (cube_data[F][3]==color) sideface = L;
    else if (cube_data[F][5]==color) sideface = R;
    else if (cube_data[F][7]==color) sideface = D;

    switch (sideface){
        case L:
            MoveL();
            MoveD();
            MoveLprime();
            break;
        case R:
            MoveRprime();
            MoveD();
            MoveR();
            break;
        case U:
            MoveF();
            MoveRprime();
            MoveD();
            MoveR();
            MoveFprime();
            break;
        default:
            MoveFprime();
            MoveRprime();
            MoveD();
            MoveR();
            MoveF();
            break;
    }
}

void RubiksCubeSolver::GetToTop(){

    int me = -1;

    // who is white
    if (cube_data[D][1] == WHITE) me = 1;
    if (cube_data[D][3] == WHITE) me = 3;
    if (cube_data[D][5] == WHITE) me = 5;
    if (cube_data[D][7] == WHITE) me = 7;

    // which face has my adjacent color as center-bring to front
    if      (side.color[D][me] == cube_data[L][4]) BringToFront(L);
    else if (side.color[D][me] == cube_data[R][4]) BringToFront(R);
    else if (side.color[D][me] == cube_data[B][4]) BringToFront(B);

    // who is white
    if      (cube_data[D][1] == WHITE && side.color[D][1] == cube_data[F][4]) me = 1;
    else if (cube_data[D][3] == WHITE && side.color[D][3] == cube_data[F][4]) me = 3;
    else if (cube_data[D][5] == WHITE && side.color[D][5] == cube_data[F][4]) me = 5;
    else if (cube_data[D][7] == WHITE && side.color[D][7] == cube_data[F][4]) me = 7;

    // bring to top
    if (me==1){
        MoveD2();
        MoveF2();
    }
    if (me==3){
        MoveD();
        MoveF2();
    }
    if (me==5){
        MoveDprime();
        MoveF2();
    }
    if (me==7){
        MoveF2();
    }

}

/*=========================================================================

  Here we are solving the first layer by inserting corner pieces
  in their appropriate locations.  To be inserted, a corner must
  be in the third row with WHITE exposed to a side.  

  There are four possible incorrect spots a WHITE corner could be.
  1. Upper face in wrong position
  2. Side face in top row
  3. Side face in bottom row
  4  Down face 

=========================================================================*/

void RubiksCubeSolver::SolveTopLayer(){

    int found,position,exposed,under,targetside,sum;

    for (int i = 0; i < 4; i++){
        position=-1;
        found = FindCorner(position);

        if (found==-1){
            // must be on top or down face

            // check is fist layer is solved
            IsSolved();
            if (TopSolved[0]+TopSolved[2]+TopSolved[6]+TopSolved[8]==4) break;

            // check if piece is in fist layer in wrong position
            found=-1;
            if (!TopSolved[0] && cube_data[U][0]==WHITE){
                found=1;
                BringToFront(L);
            }
            else if (!TopSolved[2] && cube_data[U][2]==WHITE){
                BringToFront(B);
                found=1;
            }
            else if (!TopSolved[8] && cube_data[U][8]==WHITE){
                BringToFront(R);
                found=1;
            }
            else if (!TopSolved[6] && cube_data[U][6]==WHITE){
                found=1;
            }


            if (found==1){

                MoveL();
                MoveD();
                MoveLprime();
                found=FindCorner(position);

            }else{ // check if piece is in bottom layer
            
                // first rotate cube_data so empty corner is in up,8
                if (cube_data[U][0]!=WHITE) BringToFront(B);
                else if (cube_data[U][2]!=WHITE) BringToFront(R);
                else if (cube_data[U][6]!=WHITE) BringToFront(L);


                // now move white piece to down,6
                if (cube_data[D][0]==WHITE){
                   found=1;
                   MoveD();
                }
                else if (cube_data[D][2]==WHITE){
                   found=1;
                   MoveD2();
                }
                else if (cube_data[D][8]==WHITE){
                   found=1;
                   MoveDprime();
                }
                else if (cube_data[D][6]==WHITE){
                   found=1;
                }

                // insert bottom white piece into top layer
                MoveRprime();
                MoveD();
                MoveR();

                // look for piece again
                found = FindCorner(position);
            }

            if (found==-1){

                printf("didn't find a corner - something is wrong here.\n");
                exit(0);
            }

        }

        PrintCube3D();

        InsertCorner(position);

        printf("  inserted corner # %i      moves: %3i\n",i+1,moves);

    }

    // check if we really solved the top layer
    IsSolved();
    if (!SolvedTop){
        printf("  first layer is not solved.\n");
        exit(0);
    }

#ifdef PAUSE
    char ch = getchar();
#endif

}

int RubiksCubeSolver::FindCorner(int&position){

  int found=-1;

// HEY debugging here.

  // loop over 4 side faces:
  for (int i = 1; i < 5; i++){
      if (cube_data[i][0] == WHITE){
          position = 0;
          found = 1;
      }else if (cube_data[i][2] == WHITE){
          position = 2;
          found = 1;
      }else if (cube_data[i][6] == WHITE){
          position = 6;
          found = 1;
      }else if (cube_data[i][8] == WHITE){
          position = 8;
          found = 1;
      }
      if (found==1){
          BringToFront(i);
          if (cube_data[F][0] == WHITE) position = 0;
          else if (cube_data[F][2] == WHITE) position = 2;
          else if (cube_data[F][6] == WHITE) position = 6;
          else if (cube_data[F][8] == WHITE) position = 8;
          return found;
      }
  }
  return found;
}

void RubiksCubeSolver::InsertCorner(int position){

  int exposed,under,targetside=-1;

  // corner should now be on front face:
  if (position==0){
      MoveFprime();
      MoveDprime();
      MoveF();
      BringToFront(L);
      targetside = L;
  }
  if (position==2){
      MoveF();
      MoveD();
      MoveFprime();
      BringToFront(R);
      targetside = R;
  }
  if (position==6) targetside = L;
  if (position==8) targetside = R;

  // corner should now be on front in bottom layer on L or R side
  if (targetside==L){
      // find the top corner that matches cornerprime - only 4 options
      exposed = cornerprime.color[F][6];
      under   = corner.color[F][6];

      if (cube_data[L][4] == exposed){
          if (cube_data[F][4] == under){
              MoveD();
              MoveL();
              MoveDprime();
              MoveLprime();
          }else{
              MoveB();
              MoveDprime();
              MoveBprime();
          }
      }
      if (cube_data[R][4] == exposed){
          if (cube_data[F][4] == under){
              MoveD2();
              MoveF();
              MoveDprime();
              MoveFprime();
          }else{
              MoveR();
              MoveD2();
              MoveRprime();
          }
      }
      if (cube_data[F][4] == exposed){
          if (cube_data[L][4] == under){
              MoveD();
              MoveL();
              MoveDprime();
              MoveLprime();
          }else{
              MoveD2();
              MoveF();
              MoveDprime();
              MoveFprime();
          }
      }
      if (cube_data[B][4] == exposed){
          if (cube_data[L][4] == under){
              MoveB();
              MoveDprime();
              MoveBprime();
          }else{
              MoveR();
              MoveD2();
              MoveRprime();
          }
      }
  }else{
      // find the top corner that matches cornerprime - only 4 options
      exposed = corner.color[F][8];
      under   = cornerprime.color[F][8];

      if (cube_data[L][4] == exposed){
         if (cube_data[F][4] == under){
            printf("i don't think this is possible\n");
            exit(0);
         }
         else{
            MoveLprime();
            MoveD2();
            MoveL();
         }
      }
      else if (cube_data[R][4] == exposed){
          if (cube_data[F][4] == under){
              MoveDprime();
              MoveRprime();
              MoveD();
              MoveR();
          }else{
              printf("i don't think this is possible\n");
              exit(0);
          }
      }else if (cube_data[F][4] == exposed){
          if (cube_data[L][4] == under){
              MoveD2();
              MoveFprime();
              MoveD();
              MoveF();
          }else{
              printf("i don't think this is possible\n");
              exit(0);
          }
      }else if (cube_data[B][4] == exposed){
          if (cube_data[L][4] == under){
              printf("i don't think this is possible\n");
              exit(0);
          }else{
              // R is under
              MoveBprime();
              MoveD();
              MoveB();

              //MoveLprime();
              //MoveD2();
              //MoveL();
          }
      }
  }

  PrintCube3D();

}

void RubiksCubeSolver::SolveMiddleLayer(){

    int wrong = F;
    for (int i = 0; i < 4; i++){
        int found = FindEdge();

        // edge is either already solved, or in position backward
        if (!found){
            // first check if its already solved
            wrong = -1;
            if (cube_data[F][3]!=cube_data[F][4]) wrong = F;
            if (cube_data[F][5]!=cube_data[F][4]) wrong = F;
            if (cube_data[L][1]!=cube_data[L][4]){
                wrong = L;
                BringToFront(L);
            }
            if (cube_data[L][7]!=cube_data[L][4]){
                wrong = L;
                BringToFront(L);
            }
            if (cube_data[R][1]!=cube_data[R][4]){
                BringToFront(R);
                wrong = R;
            }
            if (cube_data[R][7]!=cube_data[R][4]){
                BringToFront(R);
                wrong = R;
            }
            if (cube_data[B][3]!=cube_data[B][4]){
                BringToFront(B);
                wrong = B;
            }
            if (cube_data[B][5]!=cube_data[B][4]){
                BringToFront(B);
                wrong = B;
            }
            if (wrong==-1){
#ifdef DEBUG
                printf(" edge must be in correct position already\n");
                //printf(" edge is in wrong position\n");
                //exit(0);
#endif
            }else{
                if (cube_data[F][5]!=cube_data[F][4]) BringToFront(R);
                MoveD();
                MoveL();
                MoveDprime();
                MoveLprime();
                MoveDprime();
                MoveFprime();
                MoveD();
                MoveF();
                FindEdge();
            }
        }

        int color = cube_data[F][7];
        if (color == cube_data[L][4]){
            MoveDprime();
            BringToFront(L);
        }else if (color == cube_data[B][4]){
            MoveD2();
            BringToFront(B);
        }else if (color == cube_data[R][4]){
            MoveD();
            BringToFront(R);
        }

        if (wrong!=-1) InsertEdge();
        printf("  inserted edge # %i        moves: %3i\n",i+1,moves);
    }

    // check if we really solved the middle layer
    IsSolved();
    if (!SolvedMiddle){
        printf("  middle layer is not solved.\n");
        exit(0);
    }

#ifdef PAUSE
    char ch = getchar();
#endif
 
}

int RubiksCubeSolver::FindEdge(){

    int color = cube_data[D][4];
    if (cube_data[F][7]!=color && cube_data[D][7]!=color){
        return 1;
    }
    if (cube_data[L][3]!=color && cube_data[D][3]!=color){
        BringToFront(L);
        return 1;
    }
    if (cube_data[R][5]!=color && cube_data[D][5]!=color){
        BringToFront(R);
        return 1;
    }
    if (cube_data[B][1]!=color && cube_data[D][1]!=color){
        BringToFront(B);
        return 1;
    }
    return 0;
}

void RubiksCubeSolver::InsertEdge(){

    if (cube_data[D][7]==cube_data[L][4]){
        MoveD();
        MoveL();
        MoveDprime();
        MoveLprime();
        MoveDprime();
        MoveFprime();
        MoveD();
        MoveF();
    }else if (cube_data[D][7]==cube_data[R][4]){
        BringToFront(R);
        MoveDprime();
        MoveFprime();
        MoveD();
        MoveF();
        MoveD();
        MoveL();
        MoveDprime();
        MoveLprime();
    }else {
        printf(" uh oh my cube_data isn't solvable\n");
        exit(0);
    }
}

void RubiksCubeSolver::FormBottomCross(){

    int state = 0;
    int solved=999;
    int lshaped=0;
    int line=1;
    int neither=2;
    BringToTop(D);

    // state 999 = solved
    while(state!=solved){

        state = BottomCrossState();

        if (state==-1){
            printf(" what state is bottom in?\n");
        }

        if (state==lshaped){
            if (cube_data[U][1]!=cube_data[U][4]){
                if (cube_data[U][5]!=cube_data[U][4])  BringToFront(R);
                else if(cube_data[U][3]!=cube_data[U][4]) BringToFront(B);
            }else if (cube_data[U][3]!=cube_data[U][4]){
                if (cube_data[U][7]!=cube_data[U][4])  BringToFront(L);
            }
            MoveF();
            MoveU();
            MoveR();
            MoveUprime();
            MoveRprime();
            MoveFprime();
        }
        if (state==line){
            if (cube_data[U][1]==cube_data[U][4]) BringToFront(R);
            MoveF();
            MoveR();
            MoveU();
            MoveRprime();
            MoveUprime();
            MoveFprime();
        }
        if (state==neither){
            printf("      bottom state neither l-shaped nor line\n");

            // apply one of the moves algorithms to try to get to a line or l-shape
            /*MoveF();
            MoveU();
            MoveR();
            MoveUprime();
            MoveRprime();
            MoveFprime();*/
            MoveF();
            MoveR();
            MoveU();
            MoveRprime();
            MoveUprime();
            MoveFprime();

            printf("      checking bottom state again...\n");
        }
    }
    printf("  formed bottom cross      moves: %3i\n",moves);

#ifdef PAUSE
    char ch = getchar();
#endif

}

void RubiksCubeSolver::PermuteBottomCorners(){

    // can do this by checking the order of corners (clockwise)

    // identify correct order:
    int corner1 = WhichCorner(cube_data[L][7],cube_data[F][3],cube_data[U][4]);
    int corner2 = WhichCorner(cube_data[B][3],cube_data[L][1],cube_data[U][4]);
    int corner3 = WhichCorner(cube_data[R][1],cube_data[B][5],cube_data[U][4]);
    int corner4 = WhichCorner(cube_data[F][5],cube_data[R][7],cube_data[U][4]);

    // identify current state
    int mycorner1 = WhichCorner(cube_data[F][0],cube_data[L][8],cube_data[U][6]);
    int mycorner2 = WhichCorner(cube_data[L][2],cube_data[B][6],cube_data[U][0]);
    int mycorner3 = WhichCorner(cube_data[B][8],cube_data[R][0],cube_data[U][2]);
    int mycorner4 = WhichCorner(cube_data[R][6],cube_data[F][2],cube_data[U][8]);

    // which corner is corner 1? rotate top piece
    int temp1,temp2;
    if (mycorner2==corner1) MoveUprime();
    if (mycorner3==corner1) MoveU2();
    if (mycorner4==corner1) MoveU();
    mycorner1 = WhichCorner(cube_data[F][0],cube_data[L][8],cube_data[U][6]);
    mycorner2 = WhichCorner(cube_data[L][2],cube_data[B][6],cube_data[U][0]);
    mycorner3 = WhichCorner(cube_data[B][8],cube_data[R][0],cube_data[U][2]);
    mycorner4 = WhichCorner(cube_data[R][6],cube_data[F][2],cube_data[U][8]);

    //LU'R'UL'U'RU2

    // which corners need to be swapped?

    // 1234 - done
    if (mycorner2==corner2 && mycorner3==corner3 && mycorner4==corner4) return;

    // 1243 - swap 3/4
    if (mycorner2==corner2 && mycorner3==corner4 && mycorner4==corner3){
        SwapCorners();
        return;
    }
    // 1342 - swap 1/2 
    if (mycorner2==corner3 && mycorner3==corner4 && mycorner4==corner2){
        BringToFront(L);
        SwapCorners();
        return;
    }

    // 1423 - swap 1/4
    if (mycorner2==corner4 && mycorner3==corner2 && mycorner4==corner3){
        BringToFront(B);
        SwapCorners();
        return;
    }

    // 1324 - swap 2/3 (this is diagonal)
    // 1432 - swap 4/2 (this is diagonal)

    // for all diagonal options:
    SwapCorners();
    PermuteBottomCorners();
}

// four choices for bottom state
// solved = 999
// l-shaped = 0
// line = 1
// neither = 2
int RubiksCubeSolver::BottomCrossState(){

    int color,*face;
    int solved=999;
    int lshaped=0;
    int line=1;
    int neither=2;
    face = cube_data[U];
    color = face[4];
    if (face[1]==color){
        if (face[3]==color){
            if (face[5]==color){
                if (face[7]==color){
                    return solved;
                }
                return neither;
            }
            return lshaped;
        }else if (face[5]==color){
            if (face[7]==color) return neither;
            return lshaped;
        }else if (face[7]==color){
            return line;
        }
        return neither;
    }else if (face[3]==color){
        if (face[5]==color){
            if (face[7]==color) return neither;
            return line;
        }else if (face[7]==color) return lshaped;
        return neither;
    }else if (face[5]==color){
        if (face[7]==color) return lshaped;
        return neither;
    }
    return neither;
}

int RubiksCubeSolver::WhichCorner(int i,int j,int k){

    int bottom = cube_data[U][4];
    if (k==bottom){
        if (i<j) return (j+1)*j/2+i;
        return (i+1)*i/2+j;
    }else if (j==bottom){
        if (i<k) return (k+1)*k/2+i;
        return (i+1)*i/2+k;
    }else if (i==bottom){
        if (j<k) return (k+1)*k/2+j;
        return (j+1)*j/2+k;
    }
    printf(" corner piece does not have bottom-colored side\n");
    exit(0);
    return -999;
}

void RubiksCubeSolver::SwapCorners(){

    MoveL();
    MoveUprime();
    MoveRprime();
    MoveU();
    MoveLprime();
    MoveUprime();
    MoveR();
    MoveU2();
}

void RubiksCubeSolver::OrientBottomCorners(){

    // first rotate so corners are lined up.
    int corner1 = WhichCorner(cube_data[L][7],cube_data[F][3],cube_data[U][4]);
    int corner2 = WhichCorner(cube_data[B][3],cube_data[L][1],cube_data[U][4]);
    int corner3 = WhichCorner(cube_data[R][1],cube_data[B][5],cube_data[U][4]);
    int corner4 = WhichCorner(cube_data[F][5],cube_data[R][7],cube_data[U][4]);

    int mycorner2 = WhichCorner(cube_data[L][2],cube_data[B][6],cube_data[U][0]);
    int mycorner3 = WhichCorner(cube_data[B][8],cube_data[R][0],cube_data[U][2]);
    int mycorner4 = WhichCorner(cube_data[R][6],cube_data[F][2],cube_data[U][8]);

    if (mycorner2==corner1) MoveUprime();
    if (mycorner3==corner1) MoveU2();
    if (mycorner4==corner1) MoveU();

    int state = WhichBottomState();
    printf("      corner state %i\n",state);
    if (state!=0) SolveBottomState(state);

    printf("  orient bottom corners    moves: %3i\n",moves);

#ifdef PAUSE
    char ch = getchar();
#endif

}


int RubiksCubeSolver::WhichBottomState(){
    int state,count=0;
    state = -999;
    int *u,*f,*r,*l,*b;
    u=cube_data[U];
    f=cube_data[F];
    r=cube_data[R];
    l=cube_data[L];
    b=cube_data[B];
    count += (u[0]==u[4]);
    count += (u[2]==u[4]);
    count += (u[6]==u[4]);
    count += (u[8]==u[4]);
    if (count==4) state = 0;
    else if (count==0){
        if (b[6]==b[8] && f[0]==f[2]) state = 7;
        else if (r[0]==r[6] && l[2]==l[8]) state = 7;
        else state = 6;
    }else if (count==1){
        if (b[8]==r[6] && r[6]==f[0]) state = 1;
        else if (r[6]==f[0] && f[0]==l[2]) state = 1;
        else if (f[0]==l[2] && l[2]==b[8]) state = 1;
        else if (l[2]==b[8] && b[8]==r[6]) state = 1;
        else state = 2;
    }else{
        if (u[0]==u[8] || u[2]==u[6]) state = 5;
        else if (b[8]==f[2] && b[8]==u[4]) state = 4;
        else if (b[6]==f[0] && b[6]==u[4]) state = 4;
        else if (r[0]==l[2] && r[0]==u[4]) state = 4;
        else if (r[6]==l[8] && r[6]==u[4]) state = 4;
        else state = 3;
    }
    return state;
}

void RubiksCubeSolver::SolveBottomState(int state){

    int bottom=cube_data[U][4];
    int state2;
    char ch;
    switch (state){
        case 1:
            // bring bottom-colored piece to u(0)
            if (cube_data[U][2]==bottom)      BringToFront(L);//MoveUprime();
            else if (cube_data[U][6]==bottom) BringToFront(R);//MoveU();
            else if (cube_data[U][8]==bottom) BringToFront(B);//MoveU2();
            State1Algorithm();
            break;
        case 2:
            // bring bottom-colored piece to u(6)
            if (cube_data[U][0]==bottom)      BringToFront(L);//MoveUprime();
            else if (cube_data[U][2]==bottom) BringToFront(B);//MoveU2();
            else if (cube_data[U][8]==bottom) BringToFront(R);//MoveU();
            State2Algorithm();
            break;
        case 3:
            if (cube_data[L][2]==bottom)      BringToFront(R);//MoveU();
            else if (cube_data[F][0]==bottom) BringToFront(B);//MoveU2();
            else if (cube_data[R][0]==bottom) BringToFront(L);//MoveUprime();
            State1Algorithm();
            BringToFront(B);//MoveU2();
            State2Algorithm();
            break;
        case 4:
            if (cube_data[B][8]==bottom)      BringToFront(B);//MoveU2();
            else if (cube_data[L][2]==bottom) BringToFront(L);//MoveUprime();
            else if (cube_data[L][8]==bottom) BringToFront(R);//MoveU();
            State2Algorithm();
            State1Algorithm();
            break;
        case 5:
            if (cube_data[L][8]==bottom)      BringToFront(R);
            else if (cube_data[R][0]==bottom) BringToFront(L);
            else if (cube_data[F][2]==bottom) BringToFront(B);
            State1Algorithm();
            BringToFront(R);
            State2Algorithm();
            break;
        case 6:
            if (cube_data[B][6]==bottom && cube_data[B][8]==bottom)      BringToFront(L);
            else if (cube_data[R][0]==bottom && cube_data[R][6]==bottom) BringToFront(B);
            else if (cube_data[F][0]==bottom && cube_data[F][2]==bottom) BringToFront(R);
            State2Algorithm();
            BringToFront(R);
            State2Algorithm();
            break;
        case 7:
            if (cube_data[B][6]==bottom) BringToFront(R);
            State1Algorithm();
            BringToFront(B);
            State1Algorithm();
            break;
    }
}

void RubiksCubeSolver::State1Algorithm(){

    MoveRprime();
    MoveUprime();
    MoveR();
    MoveUprime();
    MoveRprime();
    MoveU2();
    MoveR(); 
    MoveU2();
}     

void RubiksCubeSolver::State2Algorithm(){

    MoveR();
    MoveU();
    MoveRprime();
    MoveU(); 
    MoveR(); 
    MoveU2();
    MoveRprime();
    MoveU2();
} 

void RubiksCubeSolver::PermuteBottomEdges(){

    int state = WhichBottomEdgeState();
    printf("      edge state %i\n",state);

    int * f = cube_data[F];
    int * r = cube_data[R];
    int * l = cube_data[L];
    int * b = cube_data[B];

    switch (state){
        case 0:
            break;
        case 1:
            if (l[5]==r[4])      BringToFront(L);
            else if (b[7]==f[4]) BringToFront(B);
            else if (r[3]==l[4]) BringToFront(R);
            EdgeState1Algorithm();
            break;
        case 2:
            if (r[3]==l[4])      BringToFront(L);
            else if (f[1]==b[4]) BringToFront(B);
            else if (l[5]==r[4]) BringToFront(R);
            EdgeState2Algorithm();
            break;
        case 3:
            EdgeState1Algorithm();
            PermuteBottomEdges();
            break;
        case 4:
            EdgeState1Algorithm();
            PermuteBottomEdges();
            break;
    }
    if (state==1 || state==2) {
        printf("  permute bottom edges     moves: %3i\n",moves);
#ifdef PAUSE
        char ch = getchar();
#endif
    }
}

int RubiksCubeSolver::WhichBottomEdgeState(){

    int state=0;

    int * f = cube_data[F];
    int * r = cube_data[R];
    int * l = cube_data[L];
    int * b = cube_data[B];

    if      (f[1]==b[4] && b[7]==r[4]) state = 1; 
    else if (l[5]==r[4] && r[3]==f[4]) state = 1;
    else if (b[7]==f[4] && f[1]==l[4]) state = 1;
    else if (r[3]==l[4] && l[5]==b[4]) state = 1;
    else if (b[7]==f[4] && f[1]==r[4]) state = 2;
    else if (l[5]==r[4] && r[3]==b[4]) state = 2;
    else if (f[1]==b[4] && b[7]==l[4]) state = 2;
    else if (r[3]==l[4] && l[5]==f[4]) state = 2;
    else if (b[7]==f[4] && f[1]==b[4]) state = 3;
    else if (b[7]==r[4] && l[5]==f[4]) state = 4;
    else if (b[7]==l[4] && r[3]==f[4]) state = 4;

    return state;
}

void RubiksCubeSolver::EdgeState1Algorithm(){

    MoveR2();
    MoveU();
    MoveF();
    MoveBprime();
    MoveR2();
    MoveFprime();
    MoveB();
    MoveU();
    MoveR2();
}   

void RubiksCubeSolver::EdgeState2Algorithm(){

    MoveR2();
    MoveUprime();
    MoveF();
    MoveBprime();
    MoveR2();
    MoveFprime();
    MoveB(); 
    MoveUprime();
    MoveR2();
}   


