#include"cube.hpp"

using namespace std;

// cube_data 2D layout

/*===============================================
     b           3
   l u r       2 0 4
     f   d       1    5


               0|1|2                            
               3|4|5                            
               6|7|8                            
                                                
        0|1|2  0|1|2  0|1|2                     
        3|4|5  3|4|5  3|4|5                     
        6|7|8  6|7|8  6|7|8                     
                                                
               0|1|2            0|1|2           
               3|4|5            3|4|5           
               6|7|8            6|7|8           
                                                
===============================================*/

// Constructor
RubiksCube::RubiksCube(){

    moves        = 0;
    setup        = 1;
    FormedCross  = 0;
    SolvedTop    = 0;
    SolvedMiddle = 0;

    // 6 faces  top (0), bottom (1), left (2), right (3), front (4), back(5)
    cube_data         = (int**)malloc(sizeof(int*)*6);
    temp_cube_data    = (int**)malloc(sizeof(int*)*6);

    side.face         = (int**)malloc(sizeof(int*)*6);
    side.color        = (int**)malloc(sizeof(int*)*6);

    corner.face       = (int**)malloc(sizeof(int*)*6);
    corner.color      = (int**)malloc(sizeof(int*)*6);

    cornerprime.face  = (int**)malloc(sizeof(int*)*6);
    cornerprime.color = (int**)malloc(sizeof(int*)*6);

    for (int i = 0; i < 6; i++){
        cube_data[i]         = (int*)malloc(sizeof(int)*9);
        temp_cube_data[i]    = (int*)malloc(sizeof(int)*9);
        side.face[i]         = (int*)malloc(sizeof(int)*9);
        side.color[i]        = (int*)malloc(sizeof(int)*9);
        corner.face[i]       = (int*)malloc(sizeof(int)*9);
        corner.color[i]      = (int*)malloc(sizeof(int)*9);
        cornerprime.face[i]  = (int*)malloc(sizeof(int)*9);
        cornerprime.color[i] = (int*)malloc(sizeof(int)*9);
        for (int j = 0; j < 9; j++){
            cube_data[i][j]      = i;
            temp_cube_data[i][j] = i;
        }
    }  
    TopSolved    = (int*)malloc(sizeof(int)*9);
    MiddleSolved = (int**)malloc(sizeof(int*)*6);
    for (int i = 0; i < 9; i++){
        TopSolved[i] = 0;
    }
    for (int i = 0; i < 6; i++){
        MiddleSolved[i] = (int*)malloc(sizeof(int*)*6);
        for (int j = 0; j < 6; j++){
            MiddleSolved[i][j] = 0;
        }
    }
    IsTouching();
  
    // ramdomize initial state
    JumbleCube();
}

// Destructor
RubiksCube::~RubiksCube(){
    for (int i = 0; i < 6; i++){
        free(cube_data[i]);
        free(temp_cube_data[i]);
        free(side.face[i]);
        free(side.color[i]);
        free(corner.face[i]);
        free(corner.color[i]);
        free(cornerprime.face[i]);
        free(cornerprime.color[i]);
    }
    free(cube_data);
    free(temp_cube_data);
    free(side.face);
    free(side.color);
    free(corner.face);
    free(corner.color);
    free(cornerprime.face);
    free(cornerprime.color);
}

void RubiksCube::IsSolved(){

    // corners on top row
    if (FormedCross && !SolvedTop){
        for (int i = 0; i < 9; i++){
            TopSolved[i] = 0;
        }
        if (cube_data[U][0]==WHITE){
            if (cube_data[L][2]==cube_data[L][4] && cube_data[B][6]==cube_data[B][4]) TopSolved[0] = 1;
        }
        if (cube_data[U][2]==WHITE){
            if (cube_data[R][0]==cube_data[R][4] && cube_data[B][8]==cube_data[B][4]) TopSolved[2] = 1;
        }
        if (cube_data[U][6]==WHITE){
            if (cube_data[L][8]==cube_data[L][4] && cube_data[F][0]==cube_data[F][4]) TopSolved[6] = 1;
        }
        if (cube_data[U][8]==WHITE){
            if (cube_data[R][6]==cube_data[R][4] && cube_data[F][2]==cube_data[F][4]) TopSolved[8] = 1;
        }

        if (TopSolved[8]+TopSolved[6]+TopSolved[2]+TopSolved[0]==4) SolvedTop=1;
    }

    // middle row
    if (SolvedTop && !SolvedMiddle){
        for (int i = 0; i < 6; i++){
            for (int j = 0; j < 6; j++){
                MiddleSolved[i][j] = 0;
            }
        }
        if (cube_data[F][3]==cube_data[F][4] && cube_data[L][7] == cube_data[L][4]) MiddleSolved[F][L] = MiddleSolved[L][F] = 1;
        if (cube_data[F][5]==cube_data[F][4] && cube_data[R][7] == cube_data[R][4]) MiddleSolved[F][R] = MiddleSolved[R][F] = 1;
        if (cube_data[L][1]==cube_data[L][4] && cube_data[B][3] == cube_data[B][4]) MiddleSolved[B][L] = MiddleSolved[L][B] = 1;
        if (cube_data[B][5]==cube_data[B][4] && cube_data[R][1] == cube_data[R][4]) MiddleSolved[B][R] = MiddleSolved[R][B] = 1;

        if (MiddleSolved[F][L]+MiddleSolved[F][R]+MiddleSolved[B][L]+MiddleSolved[B][R]==4) SolvedMiddle=1;
    }
 
}

void RubiksCube::IsTouching(){

    // corner pieces: what colors are adjacent
  
    // Down
    corner.color[D][0] = cube_data[B][0];
    corner.color[D][2] = cube_data[R][2];
    corner.color[D][6] = cube_data[L][6];
    corner.color[D][8] = cube_data[F][8];
    corner.face[D][0] = B;
    corner.face[D][2] = R;
    corner.face[D][6] = L;
    corner.face[D][8] = F;
  
    cornerprime.color[D][0] = cube_data[L][0];
    cornerprime.color[D][2] = cube_data[B][2];
    cornerprime.color[D][6] = cube_data[F][6];
    cornerprime.color[D][8] = cube_data[R][8];
    cornerprime.face[D][0] = L;
    cornerprime.face[D][2] = B;
    cornerprime.face[D][6] = F;
    cornerprime.face[D][8] = R;
  
    // Right
    corner.color[R][0] = cube_data[U][2];
    corner.color[R][2] = cube_data[B][2];
    corner.color[R][6] = cube_data[F][2];
    corner.color[R][8] = cube_data[D][8];
    corner.face[R][0] = U;
    corner.face[R][2] = B;
    corner.face[R][6] = F;
    corner.face[R][8] = D;
  
    cornerprime.color[R][0] = cube_data[B][8];
    cornerprime.color[R][2] = cube_data[D][2];
    cornerprime.color[R][6] = cube_data[U][2];
    cornerprime.color[R][8] = cube_data[F][8];
    cornerprime.face[R][0] = B;
    cornerprime.face[R][2] = D;
    cornerprime.face[R][6] = U;
    cornerprime.face[R][8] = F;
  
    // Back
    corner.color[B][0] = cube_data[L][0];
    corner.color[B][2] = cube_data[D][2];
    corner.color[B][6] = cube_data[U][0];
    corner.color[B][8] = cube_data[R][0];
    corner.face[B][0] = L;
    corner.face[B][2] = D;
    corner.face[B][6] = U;
    corner.face[B][8] = R;
  
    cornerprime.color[B][0] = cube_data[D][0];
    cornerprime.color[B][2] = cube_data[R][2];
    cornerprime.color[B][6] = cube_data[L][2];
    cornerprime.color[B][8] = cube_data[U][2];
    cornerprime.face[B][0] = D;
    cornerprime.face[B][2] = R;
    cornerprime.face[B][6] = L;
    cornerprime.face[B][8] = U;
  
    // Left
    cornerprime.color[L][0] = cube_data[B][0];
    cornerprime.color[L][2] = cube_data[U][0];
    cornerprime.color[L][6] = cube_data[D][6];
    cornerprime.color[L][8] = cube_data[F][0];
    cornerprime.face[L][0] = B;
    cornerprime.face[L][2] = U;
    cornerprime.face[L][6] = D;
    cornerprime.face[L][8] = F;
  
    corner.color[L][0] = cube_data[D][0];
    corner.color[L][2] = cube_data[B][6];
    corner.color[L][6] = cube_data[F][6];
    corner.color[L][8] = cube_data[U][6];
    corner.face[L][0] = D;
    corner.face[L][2] = B;
    corner.face[L][6] = F;
    corner.face[L][8] = U;
  
    // Front
    cornerprime.color[F][0] = cube_data[U][6];
    cornerprime.color[F][2] = cube_data[R][6];
    cornerprime.color[F][6] = cube_data[L][6];
    cornerprime.color[F][8] = cube_data[D][8];
    cornerprime.face[F][0] = U;
    cornerprime.face[F][2] = R;
    cornerprime.face[F][6] = L;
    cornerprime.face[F][8] = D;
  
    corner.color[F][0] = cube_data[L][8];
    corner.color[F][2] = cube_data[U][8];
    corner.color[F][6] = cube_data[D][6];
    corner.color[F][8] = cube_data[R][8];
    corner.face[F][0] = L;
    corner.face[F][2] = U;
    corner.face[F][6] = D;
    corner.face[F][8] = R;
  
    // Up
    cornerprime.color[U][0] = cube_data[B][6];
    cornerprime.color[U][2] = cube_data[R][6];
    cornerprime.color[U][6] = cube_data[L][6];
    cornerprime.color[U][8] = cube_data[F][6];
    cornerprime.face[U][0] = B;
    cornerprime.face[U][2] = R;
    cornerprime.face[U][6] = L;
    cornerprime.face[U][8] = F;
   
    corner.color[U][0] = cube_data[L][2];
    corner.color[U][2] = cube_data[B][8];
    corner.color[U][6] = cube_data[F][0];
    corner.color[U][8] = cube_data[R][6];
    corner.face[U][0] = L;
    corner.face[U][2] = B;
    corner.face[U][6] = F;
    corner.face[U][8] = R;
  
    // side pieces: what colors are adjacent
    side.color[D][1] = cube_data[B][1];
    side.color[D][3] = cube_data[L][3];
    side.color[D][5] = cube_data[R][5];
    side.color[D][7] = cube_data[F][7];
    side.face[D][1] = B;
    side.face[D][3] = L;
    side.face[D][5] = R;
    side.face[D][7] = F;
  
    side.color[R][1] = cube_data[B][5];
    side.color[R][3] = cube_data[U][5];
    side.color[R][5] = cube_data[D][5];
    side.color[R][7] = cube_data[F][5];
    side.face[R][1] = B;
    side.face[R][3] = U;
    side.face[R][5] = D;
    side.face[R][7] = F;
  
    side.color[B][1] = cube_data[D][1];
    side.color[B][3] = cube_data[L][1];
    side.color[B][5] = cube_data[R][1];
    side.color[B][7] = cube_data[F][1];
    side.face[B][1] = D;
    side.face[B][3] = L;
    side.face[B][5] = R;
    side.face[B][7] = F;
  
    side.color[L][1] = cube_data[B][3];
    side.color[L][3] = cube_data[D][3];
    side.color[L][5] = cube_data[U][3];
    side.color[L][7] = cube_data[F][3];
    side.face[L][1] = B;
    side.face[L][3] = D;
    side.face[L][5] = U;
    side.face[L][7] = F;
  
    side.color[F][1] = cube_data[U][7];
    side.color[F][3] = cube_data[L][7];
    side.color[F][5] = cube_data[R][7];
    side.color[F][7] = cube_data[D][7];
    side.face[F][1] = U;
    side.face[F][3] = L;
    side.face[F][5] = R;
    side.face[F][7] = D;
  
    side.color[U][1] = cube_data[B][7];
    side.color[U][3] = cube_data[L][5];
    side.color[U][5] = cube_data[R][3];
    side.color[U][7] = cube_data[F][1];
    side.face[U][1] = B;
    side.face[U][3] = L;
    side.face[U][5] = R;
    side.face[U][7] = F;


}

void RubiksCube::BringToFront(int face){
    switch(face){
        case R:
            RotateEquatorZ();
            MoveU();
            MoveDprime();
            moves--;
            moves--;
            break;
        case B:
            BringToFront(R);
            BringToFront(R);
            moves--;
            moves--;
            break;
        case L:
            RotateEquatorZ();
            RotateEquatorZ();
            RotateEquatorZ();
            MoveUprime();
            MoveD();
            moves--;
            moves--;
            break;
        default:
            break;
    }
}

void RubiksCube::BringToTop(int face){
    switch(face){
        case F:
            RotateEquatorX();
            MoveR();
            MoveLprime();
            moves--;
            moves--;
            break;
        case L:
            RotateEquatorY();
            MoveF();
            MoveBprime();
            moves--;
            moves--;
            break;
        case B:
            RotateEquatorX();
            RotateEquatorX();
            RotateEquatorX();
            MoveRprime();
            MoveL();
            moves--;
            moves--;
            break;
        case R:
            RotateEquatorY();
            RotateEquatorY();
            RotateEquatorY();
            MoveFprime();
            MoveB();
            moves--;
            moves--;
            break;
        case D:
            BringToTop(F);
            BringToTop(F);
            break;
        default:
            break;
    }
}

void RubiksCube::RotateEquatorY(){

    temp_cube_data[D][3] = cube_data[R][5];
    temp_cube_data[D][4] = cube_data[R][4];
    temp_cube_data[D][5] = cube_data[R][3];
  
    temp_cube_data[L][3] = cube_data[D][5];
    temp_cube_data[L][4] = cube_data[D][4];
    temp_cube_data[L][5] = cube_data[D][3];
  
    temp_cube_data[U][3] = cube_data[L][3];
    temp_cube_data[U][4] = cube_data[L][4];
    temp_cube_data[U][5] = cube_data[L][5];
  
    temp_cube_data[R][3] = cube_data[U][3];
    temp_cube_data[R][4] = cube_data[U][4];
    temp_cube_data[R][5] = cube_data[U][5];
  
    CopyCube();
}

void RubiksCube::RotateEquatorX(){

    temp_cube_data[U][1] = cube_data[F][1];
    temp_cube_data[U][4] = cube_data[F][4];
    temp_cube_data[U][7] = cube_data[F][7];
  
    temp_cube_data[B][1] = cube_data[U][1];
    temp_cube_data[B][4] = cube_data[U][4];
    temp_cube_data[B][7] = cube_data[U][7];
  
    temp_cube_data[D][1] = cube_data[B][7];
    temp_cube_data[D][4] = cube_data[B][4];
    temp_cube_data[D][7] = cube_data[B][1];
  
    temp_cube_data[F][1] = cube_data[D][7];
    temp_cube_data[F][4] = cube_data[D][4];
    temp_cube_data[F][7] = cube_data[D][1];
  
    CopyCube();
}


void RubiksCube::RotateEquatorZ(){

    temp_cube_data[L][7] = cube_data[F][5];
    temp_cube_data[L][4] = cube_data[F][4];
    temp_cube_data[L][1] = cube_data[F][3];
  
    temp_cube_data[B][3] = cube_data[L][7];
    temp_cube_data[B][4] = cube_data[L][4];
    temp_cube_data[B][5] = cube_data[L][1];
  
    temp_cube_data[R][7] = cube_data[B][5];
    temp_cube_data[R][4] = cube_data[B][4];
    temp_cube_data[R][1] = cube_data[B][3];
  
    temp_cube_data[F][3] = cube_data[R][7];
    temp_cube_data[F][4] = cube_data[R][4];
    temp_cube_data[F][5] = cube_data[R][1];
  
    CopyCube();
}


void RubiksCube::RotateUp(){

    temp_cube_data[L][2] = cube_data[F][0];
    temp_cube_data[L][5] = cube_data[F][1];
    temp_cube_data[L][8] = cube_data[F][2];
  
    temp_cube_data[B][6] = cube_data[L][8];
    temp_cube_data[B][7] = cube_data[L][5];
    temp_cube_data[B][8] = cube_data[L][2];
  
    temp_cube_data[R][6] = cube_data[B][8];
    temp_cube_data[R][3] = cube_data[B][7];
    temp_cube_data[R][0] = cube_data[B][6];
  
    temp_cube_data[F][0] = cube_data[R][6];
    temp_cube_data[F][1] = cube_data[R][3];
    temp_cube_data[F][2] = cube_data[R][0];
  
    CopyCube();
}

void RubiksCube::RotateDown(){

    temp_cube_data[R][2] = cube_data[F][8];
    temp_cube_data[R][5] = cube_data[F][7];
    temp_cube_data[R][8] = cube_data[F][6];
  
    temp_cube_data[B][0] = cube_data[R][2];
    temp_cube_data[B][1] = cube_data[R][5];
    temp_cube_data[B][2] = cube_data[R][8];
  
    temp_cube_data[L][0] = cube_data[B][2];
    temp_cube_data[L][3] = cube_data[B][1];
    temp_cube_data[L][6] = cube_data[B][0];
  
    temp_cube_data[F][6] = cube_data[L][0];
    temp_cube_data[F][7] = cube_data[L][3];
    temp_cube_data[F][8] = cube_data[L][6];
  
    CopyCube();
}

void RubiksCube::RotateBack(){

    temp_cube_data[D][0] = cube_data[L][2];
    temp_cube_data[D][1] = cube_data[L][1];
    temp_cube_data[D][2] = cube_data[L][0];
  
    temp_cube_data[R][0] = cube_data[D][2];
    temp_cube_data[R][1] = cube_data[D][1];
    temp_cube_data[R][2] = cube_data[D][0];
  
    temp_cube_data[U][0] = cube_data[R][0];
    temp_cube_data[U][1] = cube_data[R][1];
    temp_cube_data[U][2] = cube_data[R][2];
  
    temp_cube_data[L][0] = cube_data[U][0];
    temp_cube_data[L][1] = cube_data[U][1];
    temp_cube_data[L][2] = cube_data[U][2];
  
    CopyCube();
}

void RubiksCube::RotateFront(){

    temp_cube_data[L][6] = cube_data[D][8];
    temp_cube_data[L][7] = cube_data[D][7];
    temp_cube_data[L][8] = cube_data[D][6];
  
    temp_cube_data[D][6] = cube_data[R][8];
    temp_cube_data[D][7] = cube_data[R][7];
    temp_cube_data[D][8] = cube_data[R][6];
  
    temp_cube_data[U][6] = cube_data[L][6];
    temp_cube_data[U][7] = cube_data[L][7];
    temp_cube_data[U][8] = cube_data[L][8];
  
    temp_cube_data[R][6] = cube_data[U][6];
    temp_cube_data[R][7] = cube_data[U][7];
    temp_cube_data[R][8] = cube_data[U][8];
  
    CopyCube();
}

void RubiksCube::RotateFace(int face){

    if (face!=D){
        temp_cube_data[face][0] = cube_data[face][6];
        temp_cube_data[face][1] = cube_data[face][3];
        temp_cube_data[face][2] = cube_data[face][0];
        temp_cube_data[face][3] = cube_data[face][7];
        temp_cube_data[face][4] = cube_data[face][4];
        temp_cube_data[face][5] = cube_data[face][1];
        temp_cube_data[face][6] = cube_data[face][8];
        temp_cube_data[face][7] = cube_data[face][5];
        temp_cube_data[face][8] = cube_data[face][2];
    }else{
        temp_cube_data[face][0] = cube_data[face][2];
        temp_cube_data[face][1] = cube_data[face][5];
        temp_cube_data[face][2] = cube_data[face][8];
        temp_cube_data[face][3] = cube_data[face][1];
        temp_cube_data[face][4] = cube_data[face][4];
        temp_cube_data[face][5] = cube_data[face][7];
        temp_cube_data[face][6] = cube_data[face][0];
        temp_cube_data[face][7] = cube_data[face][3];
        temp_cube_data[face][8] = cube_data[face][6];
    }
    CopyCube();
}

void RubiksCube::RotateLeft(){

    temp_cube_data[B][0] = cube_data[U][0];
    temp_cube_data[B][3] = cube_data[U][3];
    temp_cube_data[B][6] = cube_data[U][6];

    temp_cube_data[D][0] = cube_data[B][6];
    temp_cube_data[D][3] = cube_data[B][3];
    temp_cube_data[D][6] = cube_data[B][0];

    temp_cube_data[F][0] = cube_data[D][6];
    temp_cube_data[F][3] = cube_data[D][3];
    temp_cube_data[F][6] = cube_data[D][0];

    temp_cube_data[U][0] = cube_data[F][0];
    temp_cube_data[U][3] = cube_data[F][3];
    temp_cube_data[U][6] = cube_data[F][6];

    CopyCube();
}

void RubiksCube::RotateRight(){
    temp_cube_data[B][2] = cube_data[U][2];
    temp_cube_data[B][5] = cube_data[U][5];
    temp_cube_data[B][8] = cube_data[U][8];

    temp_cube_data[D][2] = cube_data[B][8];
    temp_cube_data[D][5] = cube_data[B][5];
    temp_cube_data[D][8] = cube_data[B][2];

    temp_cube_data[F][2] = cube_data[D][8];
    temp_cube_data[F][5] = cube_data[D][5];
    temp_cube_data[F][8] = cube_data[D][2];

    temp_cube_data[U][2] = cube_data[F][2];
    temp_cube_data[U][5] = cube_data[F][5];
    temp_cube_data[U][8] = cube_data[F][8];

    CopyCube();
}


void RubiksCube::CopyCube(){

    for (int i = 0; i < 6; i++){
        for (int j = 0; j < 9; j++){
            cube_data[i][j] = temp_cube_data[i][j];
        }
    }
    IsTouching();
}

void RubiksCube::MoveR(){

    RotateFace(R);
    RotateRight();
    PrintCube3D();
    moves++;
}

void RubiksCube::MoveR2(){

    MoveR();
    MoveR();
    moves--;
}

void RubiksCube::MoveRprime(){

    MoveR();
    MoveR();
    MoveR();
    moves--;
    moves--;
}

void RubiksCube::MoveL(){

    RotateFace(L);
    RotateLeft();
    RotateLeft();
    RotateLeft();
    PrintCube3D();
    moves++;
}

void RubiksCube::MoveL2(){

    MoveL();
    MoveL();
    moves--;
}

void RubiksCube::MoveLprime(){

    MoveL();
    MoveL();
    MoveL();
    moves--;
    moves--;
}

void RubiksCube::MoveU(){

    RotateFace(U);
    RotateUp();
    moves++;
    PrintCube3D();
}

void RubiksCube::MoveU2(){

    MoveU();
    MoveU();
    moves--;
}

void RubiksCube::MoveUprime(){

     MoveU();
     MoveU();
     MoveU();
     moves--;
     moves--;
}

void RubiksCube::MoveD(){

    RotateFace(D);
    RotateDown();
    moves++;
    PrintCube3D();
}

void RubiksCube::MoveD2(){

    MoveD();
    MoveD();
    moves--;
}

void RubiksCube::MoveDprime(){

    MoveD();
    MoveD();
    MoveD();
    moves--;
    moves--;
}

void RubiksCube::MoveF(){

    RotateFace(F);
    RotateFront();
    moves++;
    PrintCube3D();
}

void RubiksCube::MoveF2(){

    MoveF();
    MoveF();
    moves--;
}

void RubiksCube::MoveFprime(){

    MoveF();
    MoveF();
    MoveF();
    moves--;
    moves--;
}

void RubiksCube::MoveB(){

    RotateFace(B);
    RotateBack();
    moves++;
    PrintCube3D();
}

void RubiksCube::MoveB2(){
    MoveB();
    MoveB();
    moves--;
}

void RubiksCube::MoveBprime(){

    MoveB();
    MoveB();
    MoveB();
    moves--;
    moves--;
}


void RubiksCube::PrintCube3D(){

#ifdef VISUAL
    if (setup) return;

#ifdef DEBUG
    PrintCube();
#endif

    glPushMatrix();
    glRotatef(30.0, 1.,1.0,0.6);


    glClear(GL_COLOR_BUFFER_BIT);

    //glBegin(GL_POLYGON);

    // (UP) constant y low
    glColor3f(0.0,0.0,0.0);
    SquarePrime(0.2,0.2,0.2,0.8,0.2,0.8);
    SetColor(cube_data[D][0]);
    SquarePrime(0.22,0.2,0.22,0.38,0.2,0.38);
    SetColor(cube_data[D][3]);
    SquarePrime(0.22,0.2,0.42,0.38,0.2,0.58);
    SetColor(cube_data[D][6]);
    SquarePrime(0.22,0.2,0.62,0.38,0.2,0.78);

    SetColor(cube_data[D][1]);
    SquarePrime(0.42,0.2,0.22,0.58,0.2,0.38);
    SetColor(cube_data[D][4]);
    SquarePrime(0.42,0.2,0.42,0.58,0.2,0.58);
    SetColor(cube_data[D][7]);
    SquarePrime(0.42,0.2,0.62,0.58,0.2,0.78);

    SetColor(cube_data[D][2]);
    SquarePrime(0.62,0.2,0.22,0.78,0.2,0.38);
    SetColor(cube_data[D][5]);
    SquarePrime(0.62,0.2,0.42,0.78,0.2,0.58);
    SetColor(cube_data[D][8]);
    SquarePrime(0.62,0.2,0.62,0.78,0.2,0.78);

    // (FRONT) constant y high
    glColor3f(0.0,0.0,0.0);
    Square(0.2,0.8,0.2,0.8,0.8,0.8);
    SetColor(cube_data[U][0]);
    Square(0.22,0.8,0.22,0.38,0.8,0.38);
    SetColor(cube_data[U][3]);
    Square(0.22,0.8,0.42,0.38,0.8,0.58);
    SetColor(cube_data[U][6]);
    Square(0.22,0.8,0.62,0.38,0.8,0.78);

    SetColor(cube_data[U][1]);
    Square(0.42,0.8,0.22,0.58,0.8,0.38);
    SetColor(cube_data[U][4]);
    Square(0.42,0.8,0.42,0.58,0.8,0.58);
    SetColor(cube_data[U][7]);
    Square(0.42,0.8,0.62,0.58,0.8,0.78);

    SetColor(cube_data[U][2]);
    Square(0.62,0.8,0.22,0.78,0.8,0.38);
    SetColor(cube_data[U][5]);
    Square(0.62,0.8,0.42,0.78,0.8,0.58);
    SetColor(cube_data[U][8]);
    Square(0.62,0.8,0.62,0.78,0.8,0.78);

    // (LEFT) constant x low
    glColor3f(0.0,0.0,0.0);
    Square(0.2,0.2,0.2,0.2,0.8,0.8);
    SetColor(cube_data[L][0]);
    Square(0.2,0.22,0.22,0.2,0.38,0.38);
    SetColor(cube_data[L][3]);
    Square(0.2,0.22,0.42,0.2,0.38,0.58);
    SetColor(cube_data[L][6]);
    Square(0.2,0.22,0.62,0.2,0.38,0.78);

    SetColor(cube_data[L][1]);
    Square(0.2,0.42,0.22,0.2,0.58,0.38);
    SetColor(cube_data[L][4]);
    Square(0.2,0.42,0.42,0.2,0.58,0.58);
    SetColor(cube_data[L][7]);
    Square(0.2,0.42,0.62,0.2,0.58,0.78);

    SetColor(cube_data[L][2]);
    Square(0.2,0.62,0.22,0.2,0.78,0.38);
    SetColor(cube_data[L][5]);
    Square(0.2,0.62,0.42,0.2,0.78,0.58);
    SetColor(cube_data[L][8]);
    Square(0.2,0.62,0.62,0.2,0.78,0.78);

    // (RIGHT) constant x high
    glColor3f(0.0,0.0,0.0);
    SquarePrime(0.8,0.2,0.2,0.8,0.8,0.8);
    SetColor(cube_data[R][2]);
    SquarePrime(0.8,0.22,0.22,0.8,0.38,0.38);
    SetColor(cube_data[R][5]);
    SquarePrime(0.8,0.22,0.42,0.8,0.38,0.58);
    SetColor(cube_data[R][8]);
    SquarePrime(0.8,0.22,0.62,0.8,0.38,0.78);

    SetColor(cube_data[R][1]);
    SquarePrime(0.8,0.42,0.22,0.8,0.58,0.38);
    SetColor(cube_data[R][4]);
    SquarePrime(0.8,0.42,0.42,0.8,0.58,0.58);
    SetColor(cube_data[R][7]);
    SquarePrime(0.8,0.42,0.62,0.8,0.58,0.78);

    SetColor(cube_data[R][0]);
    SquarePrime(0.8,0.62,0.22,0.8,0.78,0.38);
    SetColor(cube_data[R][3]);
    SquarePrime(0.8,0.62,0.42,0.8,0.78,0.58);
    SetColor(cube_data[R][6]);
    SquarePrime(0.8,0.62,0.62,0.8,0.78,0.78);

    // (UP) constant z low
    glColor3f(0.0,0.0,0.0);
    Square(0.2,0.2,0.2,0.8,0.8,0.2);
    //SetColor(WHITE);
    SetColor(cube_data[B][0]);
    Square(0.22,0.22,0.2,0.38,0.38,0.2);
    SetColor(cube_data[B][1]);
    Square(0.42,0.22,0.2,0.58,0.38,0.2);
    SetColor(cube_data[B][2]);
    Square(0.62,0.22,.2,0.78,0.38,0.2);

    SetColor(cube_data[B][3]);
    Square(0.22,0.42,0.2,0.38,0.58,0.2);
    SetColor(cube_data[B][4]);
    Square(0.42,0.42,0.2,0.58,0.58,0.2);
    SetColor(cube_data[B][5]);
    Square(0.62,0.42,0.2,0.78,0.58,0.2);

    SetColor(cube_data[B][6]);
    Square(0.22,0.62,0.2,0.38,0.78,0.2);
    SetColor(cube_data[B][7]);
    Square(0.42,0.62,0.2,0.58,0.78,0.2);
    SetColor(cube_data[B][8]);
    Square(0.62,0.62,0.2,0.78,0.78,0.2);

    // (DOWN) constant z high
    glColor3f(0.0,0.0,0.0);
    SquarePrime(0.2,0.2,0.8,0.8,0.8,0.8);
    SetColor(cube_data[F][6]);
    SquarePrime(0.22,0.22,0.8,0.38,0.38,0.8);
    SetColor(cube_data[F][7]);
    SquarePrime(0.42,0.22,0.8,0.58,0.38,0.8);
    SetColor(cube_data[F][8]);
    SquarePrime(0.62,0.22,0.8,0.78,0.38,0.8);

    SetColor(cube_data[F][3]);
    SquarePrime(0.22,0.42,0.8,0.38,0.58,0.8);
    SetColor(cube_data[F][4]);
    SquarePrime(0.42,0.42,0.8,0.58,0.58,0.8);
    SetColor(cube_data[F][5]);
    SquarePrime(0.62,0.42,0.8,0.78,0.58,0.8);

    SetColor(cube_data[F][0]);
    SquarePrime(0.22,0.62,0.8,0.38,0.78,0.8);
    SetColor(cube_data[F][1]);
    SquarePrime(0.42,0.62,0.8,0.58,0.78,0.8);
    SetColor(cube_data[F][2]);
    SquarePrime(0.62,0.62,0.8,0.78,0.78,0.8);

    //glEnd();

    glPopMatrix();
    glFlush();

    glutSwapBuffers();
#endif
}

void SetColor(int color){

    if (color==WHITE) glColor3f(1,1,1);
    if (color==BLUE) glColor3f(0,0,0.7);
    if (color==GREEN) glColor3f(0,0.7,0);
    if (color==ORANGE) glColor3f(0.9,0.5,0);
    if (color==YELLOW) glColor3f(1,1,0);
    if (color==RED) glColor3f(0.7,0,0);
}


void SquarePrime(double x1,double y1,double z1,double x2,double y2,double z2){

    if (fabs(x1-x2)<1e-6){
        glBegin(GL_TRIANGLES);
            glVertex3f(x1,y1,z1);
            glVertex3f(x1,y2,z1);
            glVertex3f(x1,y2,z2);
        glEnd();

        glBegin(GL_TRIANGLES);
            glVertex3f(x1,y2,z2);
            glVertex3f(x1,y1,z2);
            glVertex3f(x1,y1,z1);
        glEnd();
    }else if (fabs(y1-y2)<1e-6){
        glBegin(GL_TRIANGLES);
            glVertex3f(x1,y1,z1);
            glVertex3f(x2,y1,z1);
            glVertex3f(x2,y1,z2);
        glEnd();

        glBegin(GL_TRIANGLES);
            glVertex3f(x2,y1,z2);
            glVertex3f(x1,y1,z2);
            glVertex3f(x1,y1,z1);
        glEnd();
    }else if (fabs(z1-z2)<1e-6){
        glBegin(GL_TRIANGLES);
            glVertex3f(x1,y1,z1);
            glVertex3f(x2,y1,z1);
            glVertex3f(x2,y2,z1);
        glEnd();

        glBegin(GL_TRIANGLES);
            glVertex3f(x2,y2,z1);
            glVertex3f(x1,y2,z1);
            glVertex3f(x1,y1,z1);
        glEnd();
    }else exit(0);

    glFlush();
}

void Square(double x1,double y1,double z1,double x2,double y2,double z2){

    if (x1==x2){
        glBegin(GL_TRIANGLES);
            glVertex3f(x1,y1,z1);
            glVertex3f(x1,y1,z2);
            glVertex3f(x1,y2,z2);
        glEnd();

        glBegin(GL_TRIANGLES);
            glVertex3f(x1,y2,z2);
            glVertex3f(x1,y2,z1);
            glVertex3f(x1,y1,z1);
        glEnd();
    }else if (y1==y2){
        glBegin(GL_TRIANGLES);
            glVertex3f(x1,y1,z1);
            glVertex3f(x1,y1,z2);
            glVertex3f(x2,y1,z2);
        glEnd();

        glBegin(GL_TRIANGLES);
            glVertex3f(x2,y1,z2);
            glVertex3f(x2,y1,z1);
            glVertex3f(x1,y1,z1);
        glEnd();
    }else if (z1==z2){
        glBegin(GL_TRIANGLES);
            glVertex3f(x1,y1,z1);
            glVertex3f(x1,y2,z1);
            glVertex3f(x2,y2,z1);
        glEnd();

        glBegin(GL_TRIANGLES);
            glVertex3f(x2,y2,z1);
            glVertex3f(x2,y1,z1);
            glVertex3f(x1,y1,z1);
        glEnd();
    }else exit(0);

    glFlush();
}


void RubiksCube::PrintCube(){

    printf("\n");
    printf("\033[22;30m------------------------------------------\n");
    printf("\n");
    printf("               ");
    PrintElement(cube_data[B][0]);
    printf("\033[22;30m|");
    PrintElement(cube_data[B][1]);
    printf("\033[22;30m|");
    PrintElement(cube_data[B][2]);
    printf("\n");
    printf("               ");
    PrintElement(cube_data[B][3]);
    printf("\033[22;30m|");
    PrintElement(cube_data[B][4]);
    printf("\033[22;30m|");
    PrintElement(cube_data[B][5]);
    printf("\n");
    printf("               ");
    PrintElement(cube_data[B][6]);
    printf("\033[22;30m|");
    PrintElement(cube_data[B][7]);
    printf("\033[22;30m|");
    PrintElement(cube_data[B][8]);
    printf("\n");
    printf("\n");
    printf("        ");
    PrintElement(cube_data[L][0]);
    printf("\033[22;30m|");
    PrintElement(cube_data[L][1]);
    printf("\033[22;30m|");
    PrintElement(cube_data[L][2]);
    printf("  ");
    PrintElement(cube_data[U][0]);
    printf("\033[22;30m|");
    PrintElement(cube_data[U][1]);
    printf("\033[22;30m|");
    PrintElement(cube_data[U][2]);
    printf("  ");
    PrintElement(cube_data[R][0]);
    printf("\033[22;30m|");
    PrintElement(cube_data[R][1]);
    printf("\033[22;30m|");
    PrintElement(cube_data[R][2]);
    printf("\n");
    printf("        ");
    PrintElement(cube_data[L][3]);
    printf("\033[22;30m|");
    PrintElement(cube_data[L][4]);
    printf("\033[22;30m|");
    PrintElement(cube_data[L][5]);
    printf("  ");
    PrintElement(cube_data[U][3]);
    printf("\033[22;30m|");
    PrintElement(cube_data[U][4]);
    printf("\033[22;30m|");
    PrintElement(cube_data[U][5]);
    printf("  ");
    PrintElement(cube_data[R][3]);
    printf("\033[22;30m|");
    PrintElement(cube_data[R][4]);
    printf("\033[22;30m|");
    PrintElement(cube_data[R][5]);
    printf("\n");
    printf("        ");
    PrintElement(cube_data[L][6]);
    printf("\033[22;30m|");
    PrintElement(cube_data[L][7]);
    printf("\033[22;30m|");
    PrintElement(cube_data[L][8]);
    printf("  ");
    PrintElement(cube_data[U][6]);
    printf("\033[22;30m|");
    PrintElement(cube_data[U][7]);
    printf("\033[22;30m|");
    PrintElement(cube_data[U][8]);
    printf("  ");
    PrintElement(cube_data[R][6]);
    printf("\033[22;30m|");
    PrintElement(cube_data[R][7]);
    printf("\033[22;30m|");
    PrintElement(cube_data[R][8]);
    printf("\n");
    printf("\n");
    printf("               ");
    PrintElement(cube_data[F][0]);
    printf("\033[22;30m|");
    PrintElement(cube_data[F][1]);
    printf("\033[22;30m|");
    PrintElement(cube_data[F][2]);
    printf("            ");
    PrintElement(cube_data[D][0]);
    printf("\033[22;30m|");
    PrintElement(cube_data[D][1]);
    printf("\033[22;30m|");
    PrintElement(cube_data[D][2]);
    printf("\n");
    printf("               ");
    PrintElement(cube_data[F][3]);
    printf("\033[22;30m|");
    PrintElement(cube_data[F][4]);
    printf("\033[22;30m|");
    PrintElement(cube_data[F][5]);
    printf("            ");
    PrintElement(cube_data[D][3]);
    printf("\033[22;30m|");
    PrintElement(cube_data[D][4]);
    printf("\033[22;30m|");
    PrintElement(cube_data[D][5]);
    printf("\n");
    printf("               ");
    PrintElement(cube_data[F][6]);
    printf("\033[22;30m|");
    PrintElement(cube_data[F][7]);
    printf("\033[22;30m|");
    PrintElement(cube_data[F][8]);
    printf("            ");
    PrintElement(cube_data[D][6]);
    printf("\033[22;30m|");
    PrintElement(cube_data[D][7]);
    printf("\033[22;30m|");
    PrintElement(cube_data[D][8]);
    printf("\n");
    printf("\n");
    printf("\033[22;30m------------------------------------------\n");
    printf("\n");
}

void RubiksCube::PrintElement(int element){
    switch (element){
        case 0: 
            printf("\033[22;31mo");  // red
            break;
        case 1:
            printf("\033[22;32mo");  // green
            break;
        case 2:
            printf("\033[22;34mo");  // blue
            break;
        case 3:
            printf("\033[01;33mo");  // yellow
            break;
        case 4:
            printf("\033[01;37mo");  // white
            break;
        case 5:
            printf("\033[22;36mo"); // cyan (no orange)
            break;
    }
}

void RubiksCube::JumbleCube(){

    //3 is 5
    //4 is 6
    //6 is 4
    //9 is 7

    srand(time(0));
    setup=1;
    for (int i = 0; i < 1000; i++){
        int move = (int)(27.0*rand()/RAND_MAX);

        switch(move){
            case 0:
                MoveU();
                break;
            case 1:
                MoveU2();
                break;
            case 2:
                MoveUprime();
                break;
            case 3:
              MoveF();
                break;
            case 4:
                MoveF2();
                break;
            case 5:
                MoveFprime();
                break;
            case 6:
                MoveL();
                break;
            case 7:
                MoveL2();
                break;
            case 8:
                MoveLprime();
                break;
            case 9:
                MoveB();
                break;
            case 10:
                MoveB2();
                break;
            case 11:
                MoveBprime();
                break;
            case 12:
                MoveR();
                break;
            case 13:
                MoveR2();
                break;
            case 14:
                MoveRprime();
                break;
            case 15:
                MoveD();
                break;
            case 16:
                MoveD2();
                break;
            case 17:
                MoveDprime();
                break;
            case 18:
                BringToFront(R);
                break;
            case 19:
                BringToFront(L);
                break;
            case 20:
                BringToFront(R);
                break;
            case 21:
                BringToFront(B);
                break;
            case 22:
                BringToTop(F);
                break;
            case 23:
                BringToTop(L);
                break;
            case 24:
                BringToTop(R);
                break;
            case 25:
                BringToTop(B);
                break;
            case 26:
                BringToTop(D);
                break;
        }
    }

    // setup is complete
    setup = 0;

    PrintCube3D();
}
