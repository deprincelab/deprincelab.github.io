#ifndef CUBE_SOLVER_HPP
#define CUBE_SOLVER_HPP

#include"cube.hpp"

class RubiksCubeSolver: public RubiksCube
{
  public:

    RubiksCubeSolver();
    ~RubiksCubeSolver();
  
    void LocateOrigin();
  
    void FormCross();
      void GetToBottom(int face,int side);
      void GetToTop();
  
    void SolveTopLayer();
      int FindCorner(int&position);
      void InsertCorner(int position);
  
    void SolveMiddleLayer();
      int FindEdge();
      void InsertEdge();
  
    void SolveBottomLayer();
  
    void FormBottomCross();
  
    void PermuteBottomCorners();
      int BottomCrossState();
      int WhichCorner(int i,int j,int k);
      void SwapCorners();
  
    void OrientBottomCorners();
      int WhichBottomState();
      void SolveBottomState(int state);
      void State1Algorithm();
      void State2Algorithm();
  
    void PermuteBottomEdges();
      int WhichBottomEdgeState();
      void EdgeState1Algorithm();
      void EdgeState2Algorithm();
  
  private:

};

#endif
