#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include<GL/gl.h>
//#include<GL/glu.h>
#include<GL/glut.h>
//#include"/Users/adeprince/Research/ParPackage/MISC/memory.h"
#include"frogger.hpp"
bool ignoreRepeats = false;

//  HAD TO DECLARE THIS GLOBALLY!
FROGGER *frog;
void keyboardUp (unsigned char key, int x, int y);
void init (void);

void keyboardUp (unsigned char key, int x, int y)
{
}//End of Function

void idle(){
  glutPostRedisplay();
  glFlush();
}
void keyboard(unsigned char key, int x, int y){
  if (!frog->splat){
  if (key==27){
     glClear (GL_COLOR_BUFFER_BIT);
     glFlush();
     exit(0);
  }
  else if (key==104){  // LEFT: 'H'
     if (frog->x>=0.075)
        frog->x-=0.05;
        frog->face=LEFT;
  }
  else if (key==108){ // RIGHT: 'L'
     if (frog->x<=0.95)
        frog->x+=0.05;
        frog->face=RIGHT;
  }
  else if (key==107){  // UP: 'K'
     if (frog->y<=0.95)
        frog->y+=0.05;
     frog->face=UP;
     if (frog->y>frog->maxy){
        frog->score += 2*frog->level;
        frog->maxy = frog->y;
     }
  }
  else if (key==106){ // DOWN: 'J'
     if (frog->y>=0.3)
        frog->y-=0.05;
        frog->face=DOWN;
  }
  }
  else {
     if (key==13 && frog->lives>0){
        frog->lives--;
        frog->splat=0;
        frog->x = 0.5;
        frog->y = 0.275;
        frog->face = UP;
        frog->maxy = -1;
     }
  }
}


void display(void){
  int i,l,t;
  double dx,dy;
  //init();
  //glLoadIdentity();
  if (frog->splat){
     frog->Screen();
     frog->Cars();
     l=frog->Logs();
     t=frog->Turtles();
     if (frog->level>0) frog->Snakes();
     frog->Splat();
     frog->Base();
     glutSwapBuffers();
  }
  else {
     frog->Screen();
     frog->Cars();
     l=frog->Logs();
     t=frog->Turtles();
     if (frog->level>0) frog->Snakes();
     if (frog->y>0.55 && frog->y<0.8 && l==0 && t==0)
        frog->Splat();
     //frog->Splat();
     frog->Frog();
     frog->Base();
     glutSwapBuffers();
  }
  //glPopMatrix();
}

void reshape(int w,int h){
    //glMatrixMode(GL_PROJECTION);
    //glLoadIdentity();
    //glutSwapBuffers();
    //glFlush();
}

void init (void) 
{
/*  select clearing (background) color       */
    glClearColor (0.0, 0.0, 0.0, 0.0);
    //glEnable(GL_DEPTH_TEST);


/*  initialize viewing values  */
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    //glOrtho(0.0, 1.0, 0.0, 1.0, 0.0, 1.0);
    glOrtho(0.0, 1.0, 0.0, 1.0, -1.0, 1.0);
}

/* 
 *  Declare initial window size, position, and display mode
 *  (single buffer and RGBA).  Open window with "hello"
 *  in its title bar.  Call initialization routines.
 *  Register callback function to display graphics.
 *  Enter main loop and process events.
 */
int main(int argc, char** argv)
{
  // BIRDS PART
  int i,c,n,maxv;
  int *x,*y,*newx,*newy,*vx,*vy;
  double turn,turn2;
  using namespace std;
  frog = new FROGGER;
  srand(time(0));

    glutInit(&argc, argv);
    glutInitDisplayMode (GLUT_DOUBLE | GLUT_RGB);
    glutInitWindowSize (500, 500); 
    glutInitWindowPosition (50, 50);
    glutCreateWindow ("FROGGER!");

    init ();
    glutKeyboardFunc(keyboard);
    glutDisplayFunc(display); 
    glutIdleFunc(idle); 
    glutMainLoop();
    return 0;   /* ISO C requires main to return int. */
}

