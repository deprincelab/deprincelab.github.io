#ifndef BIRD_HPP
#define BIRD_HPP
#include<ncurses.h>
#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include<time.h>
#include<string.h>
//#include"/Users/adeprince/Research/ParPackage/MISC/memory.h"
#include"GL/gl.h"
#include"GL/glut.h"
#include"GL/glu.h"
#define pi 3.14159265
#define  LEFT 0
#define RIGHT 1
#define    UP 2
#define  DOWN 3

using namespace std;
class FROGGER
{
public:
  ~FROGGER();
  FROGGER();
  int npred,n,height,width,face,splat,log,lives,score,level,resettime,*base;
  int rise1,rise2,dive1,dive2,diver1,diver2;
  double maxpv,maxv,dv,difficulty,timer,maxy,sink1,sink2,swap1,swap2;
  char*dot;
  double boundx,boundy,maxa,x,y,*newx,*newy,*vx,*vy,*z,*newz,*vz,**p,**pv;
  double *c1x,c1y,*c2x,c2y,*c3x,c3y,*c4x,c4y,sphase;
  double *t1x,*t2x,t1y,t2y,*l1x,l1y,*l2x,l2y,*l3x,l3y,sx,sface;
  WINDOW*menu_win;

  // FUNCTIONS:
  void circle(double r,double x, double y,double z);
  void oval(double r1,double r2,double x, double y,double z);
  void oval_nooutline(double r1,double r2,double x, double y,double z);
  void makex(double r,double x, double y,double z);
  void splatcircle(double r,double x, double y,double z);
  void Drown();
  void Splat();
  void Frog();
  void Screen();
  void Cars();
  void DrawCar(double x,double y);
  void DrawTurtle(double x,double y,int face,int dive,double sink);
  int Logs();
  int Turtles();
  void Snakes();
  void DrawSnake(double x,double y);
  void Base();

private:
  FROGGER(const FROGGER&);
  FROGGER& operator=(const FROGGER&);
};
void DrawText(GLint x,GLint y, char*s,GLfloat r,GLfloat g,GLfloat b);
//size_t strlen(const char *);
char *strrev(char *);
char *itoa(int, char *, int);

#endif
