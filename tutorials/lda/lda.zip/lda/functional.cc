/*
 * @BEGIN LICENSE
 *
 * lda by Psi4 Developer, a plugin to:
 *
 * Psi4: an open-source quantum chemistry software package
 *
 * Copyright (c) 2007-2016 The Psi4 Developers.
 *
 * The copyrights for code used from other parties are included in
 * the corresponding files.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 * @END LICENSE
 */

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <algorithm>
#include <vector>
#include <utility>
#include <tuple>
#include "psi4/libpsi4util/libpsi4util.h"

// for dft
#include "psi4/libfock/v.h"
#include "psi4/libfunctional/superfunctional.h"

// for grid
#include "psi4/libfock/points.h"
#include "psi4/libfock/cubature.h"

#include "psi4/psi4-dec.h"
#include "psi4/liboptions/liboptions.h"
#include "psi4/libpsio/psio.hpp"

#include "psi4/libmints/wavefunction.h"
#include "psi4/libmints/mintshelper.h"
#include "psi4/libmints/matrix.h"
#include "psi4/libmints/vector.h"
#include "psi4/libmints/basisset.h"
#include "psi4/libmints/molecule.h"
#include "psi4/lib3index/dftensor.h"
#include "psi4/libqt/qt.h"

// jk object
#include "psi4/libfock/jk.h"

// for dft
#include "psi4/libfock/v.h"
#include "psi4/libfunctional/superfunctional.h"

#include "dft.h"

// @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
// @ The four major conventions regarding to the principal variables used for                                              @
// @ building exchange-correlation (XC) functionals are as follows:                                                        @
// @                                                                                                                       @
// @ Convention (I)   spin densities rho_a, rho_b and their gradients:                   EXC[rho_a, rho_b, rho_a', rho_b'] @
// @ Convention (II)  total density, spin-magnetization density m and their gradients:   EXC[rho, m, rho', m']             @
// @ Convention (III) total density, spin polarization and their gradients:              EXC[rho, zeta, rho', zeta']       @
// @ Convention (IV)  singlet and triplet charge densities                                                                 @
// @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@

namespace psi{ namespace lda {

    //###########################################################
    //# The exchange and correlation functional implementations #
    //###########################################################
    //
    //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //+++++++++++++++++++ Exchange functionals ++++++++++++++++++
    //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

// Conv. (I)
double DFTSolver::EX_LSDA_I(std::shared_ptr<Vector> rho_a, std::shared_ptr<Vector> rho_b){
    
    const double alpha = (2.0/3.0);      // Slater value
    const double Cx = (9.0/8.0) * alpha * pow(3.0/M_PI,1.0/3.0);

    double * rho_ap = rho_a->pointer();
    double * rho_bp = rho_b->pointer();
    
    double exc = 0.0;
    for (int p = 0; p < phi_points_; p++) {

        double exa = pow(2.0,1.0/3.0) * Cx * pow( rho_ap[p], 4.0/3.0) ;
        double exb = pow(2.0,1.0/3.0) * Cx * pow( rho_bp[p], 4.0/3.0) ;
        double ex_LSDA = exa + exb;
        exc += - ex_LSDA * grid_w_->pointer()[p]; 
    }
    return exc;
}

    //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
    //+++++++++++++++++ Correlation Functionals +++++++++++++++++
    //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

// Conv. (III)
double DFTSolver::EC_VWN3_RPA_III(std::shared_ptr<Vector> rho_a, std::shared_ptr<Vector> rho_b){
 
    double tol = 1.0e-20;
 
    const double ecp1 = 0.03109070000;
    const double ecp2 = -0.409286;
    const double ecp3 = 13.0720;
    const double ecp4 = 42.7198;
    const double ecf1 = 0.01554535000;
    const double ecf2 = -0.743294;
    const double ecf3 = 20.1231;
    const double ecf4 = 101.578;
    const double d2Fz = 1.7099209341613656173;

    double * rho_ap = rho_a->pointer();
    double * rho_bp = rho_b->pointer();
    
    auto x = [](double RHO) -> double {

             double rs = pow( 3.0 / ( 4.0 * M_PI * RHO ) , 1.0/3.0 ); 
             double dum = sqrt(rs);
             return dum;
    };

    auto Fz = [](double ZETA) -> double {

              double dum = (pow((1.0 + ZETA) ,4.0/3.0) + pow((1.0 - ZETA) ,4.0/3.0) - 2.0) / (2.0 * pow(2.0,1.0/3.0) - 2.0);
              return dum;
    };

    auto X = [](double i, double c, double d) -> double{
             
             double temp = pow(i,2.0) + c * i + d;
             return temp;
    };
    
    auto Q = [](double c, double d) -> double{
    
             double temp1 = sqrt( 4 * d - pow(c,2.0) );
             return temp1;
    };

    auto q = [=](double RHO, double A, double p, double c, double d) -> double{
        
             double dum1 = A * ( log( pow(x(RHO),2.0) / X(x(RHO),c,d) ) + 2.0 * c * atan( Q(c,d)/(2.0*x(RHO) + c) ) * pow(Q(c,d),-1.0)    
                         - c * p * ( log( pow(x(RHO)-p,2.0) / X(x(RHO),c,d) ) + 2.0 * (c + 2.0 * p) * atan( Q(c,d)/(2.0*x(RHO) + c) ) 
                         * pow(Q(c,d),-1.0) ) * pow(X(p,c,d),-1.0) ); 
             return dum1;
    };

    auto EcP = [=](double RHO) -> double {

               double dumm = q(RHO,ecp1,ecp2,ecp3,ecp4);
               return dumm;
    };

    auto EcF = [=](double RHO) -> double {
 
               double dum = q(RHO,ecf1,ecf2,ecf3,ecf4);
               return dum;
    };

    double exc = 0.0;
    for (int p = 0; p < phi_points_; p++) {
        
        double rhoa = rho_ap[p];
        double rhob = rho_bp[p];
        double rho = rhoa + rhob;
        double zeta = 0.0;
        // double zeta = zeta_p[p];

        if ( rho > tol ) {
           if ( rhoa < tol ){
              
              rho = rhob;
              zeta = 1.0;

           }else if ( rhob < tol ){
                                  
                    rho = rhoa;
                    zeta = 1.0;

           }else {/* if (!(rhoa < tol) && !(rhob < tol) ) */

                 zeta = (rhoa - rhob) / rho;        
           }
           double zk = EcP(rho) + Fz(zeta) * (EcF(rho) - EcP(rho));
           exc += rho * zk * grid_w_->pointer()[p]; 

        }else{
                double zk = 0.0;        
                exc += 0.0;
             }
    }
    return exc;
}

}} // End namespaces
